import xlwt
import requests
import ast

"""
This takes a list of PLOS article dois and will produce a excel spreadsheet a monthly breakdown of all articles 
The list of articles can be in .txt format separated by linebreaks or csv where the list of articles are in separate cells along the same column.

Requires:
    
    - The excel file creator package xlwt available from https://pypi.python.org/pypi/xlwt
"""

class ALM:
    
    def __init__(self, dictionaryWithSourceNamesAsKeys, listOfSourceNames, doi,title):
        self.dic = dictionaryWithSourceNamesAsKeys
        self.sources = listOfSourceNames
        self.doi = str(doi)
        self.title = str(title)

def getALM(doi,url="http://alm.plos.org/api/works/"):
    
    #now add the rest of the url...
    BASE_HEADERS = {'Accept': 'application/json',"version":"6"}
    parameters= {'api_key':'PTAGXPDWSBH_CJRNJE54'}
    urlForName = url + "doi:" + str(doi)
    url += "doi:" + str(doi) + "/events"
    
        
    if url:
        resp = requests.get(url,
                            params = parameters,
                            headers=BASE_HEADERS)
        resp.raise_for_status() # check for html errors

        resp = ast.literal_eval(resp.text) ## this built in function maps the text to dictionarys/lists
        
        #we now want to arrange this into a more searchable database, we can go down a level
        
        events = resp["events"] # we only want the events since the rest of the data is only metadata on the request
        
        # events is a list of dictionaries containing all the data for a source
        # the sources names are kept under the "source_id" key in the event's dictionary.. we want this to be searchable by name since the order is not consistent between articles it seems...
        dicByName = {} 
        sources = [] # having a list of the sources so we can iterate easily on it 
        
        for a in events:
            sources.append(a["source_id"])
            dicByName[a["source_id"]] = a
        
        #do something similar to get the name
        resp = requests.get(urlForName,
                            params = parameters,
                            headers=BASE_HEADERS)
        resp.raise_for_status() # check for html errors
        resp = ast.literal_eval(resp.text)
        name = resp["work"]["title"]
         
        #create an instance of the alm class
        asAlm = ALM(dicByName,sources,doi,name)
        
        return asAlm

    else:
        return "invalid doi or url"
    
        
"""new structure!

get all the alms... separate them out into larger groups with a class for sources and articles
pick the alm with the lowest date and make the excel sheet based on it's sources and dates like below...
then run through each other alm and write in the data

we'll bypass pyalm since it no longer works

"""     
def report(articleFile, output = "output.xls"): 
       
    #articleFile = open("C:\Users\Hugh\Desktop\New OpenDocument Spreadsheet.csv")
    #articleList = articleFile.readlines()
    try: 
        articleFile = open(articleFile)
        articleList = articleFile.readlines()
    except:
        articleList = [articleFile]
    
    #cleanup the article list if they have been separated bt commas
    tempList = []
    for a in  articleList:
        a = a.rstrip(",\n")
        tempList.append(a)
    articleList = tempList

    almMasterList = [] #we want a master list to keep all the alms
    
    #collect all the alms!     
    for a in tempList:
        almMasterList.append(getALM(a))
    
    #print almMasterList[0].title
    #print almMasterList[0].dic["pmceuropedata"]["timestamp"]
    #print str((int(almMasterList[0].dic["pmceuropedata"]["timestamp"][0:4]),int(almMasterList[0].dic["pmceuropedata"]["timestamp"][5:7])))
    
    #find the oldest to make the spreadsheet from by counter
    oldestLenght = 0
    oldest = False
    for b in almMasterList:
        
        if len(b.dic["counter"]["by_month"]) > oldestLenght:
            oldestLenght = len(b.dic["counter"]["by_month"])
            oldest = b
            
    
    if oldest == False:
        return("Oldest ALM not found to build report")
        
        
    #Now we have the oldest we want to make the xls
    
    book = xlwt.Workbook(encoding="utf-8") 
    
    #set up all the sheets with article titles and dois named by source
    sheetDict = {}
    dateColumnIndexDic = {} # in the form {"sourceName": [(month,year)...]...}
    
    for sor in oldest.sources:
        sheet=book.add_sheet(sor)
        sheet.write(0, 0, "DOI")
        sheet.write(0, 1,"Title")
        
        sheetDict[sor] = sheet
        
        #while we're here lets write all the dates on every page and keep a list of the dates for each source
        months = oldest.dic[sor]["by_month"]
        listOfMonths = []#in the form [(month,year)...]
        columnForMonth = 2
        
        dateIndex = 0
        month = 0
        year = 0
        for date in months:
            if date == months[0]:
                sheet.write(0,columnForMonth, (str(months[dateIndex]["month"]) + "-" +str(months[dateIndex]["year"])))
                listOfMonths.append((months[dateIndex]["month"],months[dateIndex]["year"]))
                month = months[dateIndex]["month"]
                year = months[dateIndex]["year"]
            else:
                if(month!=12):
                    month +=1
                else:
                    month = 1
                    year +=1
                sheet.write(0,columnForMonth, str(month)+"-"+str(year))    
                listOfMonths.append((month,year))
            columnForMonth += 1
            dateIndex +=1
        try:    
            while listOfMonths[-1][1] < int(oldest.dic[sor]["timestamp"][0:4]) or listOfMonths[-1][0] < int(almMasterList[0].dic[sor]["timestamp"][5:7]):#keep adding months if we're not up to date
                #print listOfMonths[-1][1] < int(oldest.dic[sor]["timestamp"][0:4])
                if(month!=12):
                    month +=1
                else:
                    month = 1
                    year +=1
                sheet.write(0,columnForMonth, str(month)+"-"+str(year))    
                listOfMonths.append((month,year))
                columnForMonth += 1
                dateIndex +=1
        except:
            a=a
        #    print sor
        
        dateColumnIndexDic[sor] = listOfMonths
    
    #now lets run through every manuscript and write their data
    workingRow = 1
    
    for met in almMasterList:
        for s in met.sources:
            try:
                workingSheet = sheetDict[s]
            except: #if the source wasn't in the oldest we can just make it
                workingSheet = book.add_sheet(s)
                workingSheet.write(0, 0, "DOI")
                workingSheet.write(0, 1,"Title")
                
                
            workingSheet.write(workingRow,0, met.doi)
            workingSheet.write(workingRow,1, met.title)
            
            #columnInitializer = 2 # reset the columns
            
            columnIndex = False
            #dateList.index(metric.sources['counter'].by_month[0][0]) + columnForMonth
            
            for data in met.dic[s]["by_month"]:
                
                try:
                    columnIndex = dateColumnIndexDic[s].index((data["month"],data["year"])) +2
                    workingSheet.write(workingRow, columnIndex, data["total"])
                except:
                    # need to add missing dates
                    try:#what if it's empty?
                        if len(dateColumnIndexDic.keys()) == 0:
                            columnIndex = 2
                            workingSheet.write(workingRow, columnIndex, data["total"])
                            workingSheet.write(0,columnIndex, str(data["month"])+"-"+str(data["year"]))
                    except:                
                        try:#what if it's missing a more recent date?
                            columnIndex = dateColumnIndexDic[s].index((data["month"]-1,data["year"])) +3 
                            workingSheet.write(workingRow, columnIndex, data["total"])
                            workingSheet.write(0,columnIndex, str(data["month"])+"-"+str(data["year"]))
                        except:
                            return "Unable to write ALM at: " + str(met.doi) + "_" + str(s) + "_" + str(data["month"]-1)+"-"+str(data["year"])
        
            
        workingRow+=1#move to the next row for a new article
            
    
    
    try:
        book.save(output) # the path to save the output
    except:
        return "Can't access output file"


#c = report("C:\Users\Hugh\Desktop\New OpenDocument Spreadsheet.csv","C:\Users\Hugh\Desktop\output.xls")
#print c


         
                
        



